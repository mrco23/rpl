import prisma from "../config/prisma.js";
import { buildFileUrl, deleteFile } from "../utils/file.js";

// GET ALL
export const getAll = async () => {
	return prisma.berita.findMany({
		orderBy: { tanggal_dibuat: "desc" },
		select: {
			id_berita: true,
			judul_berita: true,
			deskripsi: true,
			gambar_berita: true,
			tanggal_dibuat: true,
		},
	});
};

// GET DETAIL
export const getDetail = async (id) => {
	return prisma.berita.findUnique({
		where: { id_berita: Number(id) },
	});
};

// POST: Create data beserta gambar di awal
export const createBerita = async (id_admin, payload) => {
	return prisma.berita.create({
		data: {
			judul_berita: payload.judul_berita,
			deskripsi: payload.deskripsi,
			gambar_berita: payload.gambar || null,
			id_admin: Number(id_admin),
		},
	});
};

// PUT: Update data teks saja (tanpa mengubah gambar)
export const updateBeritaData = async (id_admin, id, payload) => {
	const existing = await prisma.berita.findFirst({
		where: { id_berita: Number(id), id_admin: Number(id_admin) },
	});
	if (!existing) throw new Error("Data tidak ditemukan");

	return prisma.berita.update({
		where: { id_berita: Number(id) },
		data: {
			judul_berita: payload.judul_berita,
			deskripsi: payload.deskripsi,
		},
	});
};

// PATCH: Update khusus gambar saja
export const updateBeritaImage = async (id_admin, id, filename) => {
	const existing = await prisma.berita.findFirst({
		where: { id_berita: Number(id), id_admin: Number(id_admin) },
	});
	if (!existing) throw new Error("Data tidak ditemukan");

	if (existing.gambar_berita) {
		await deleteFile(existing.gambar_berita);
	}

	return prisma.berita.update({
		where: { id_berita: Number(id) },
		data: { gambar_berita: filename },
	});
};

// DELETE: Hapus data beserta fisik gambarnya
export const deleteBerita = async (id_admin, id) => {
	const existing = await prisma.berita.findFirst({
		where: { id_berita: Number(id), id_admin: Number(id_admin) },
	});
	if (!existing) throw new Error("Data tidak ditemukan");

	if (existing.gambar_berita) {
		await deleteFile(existing.gambar_berita);
	}

	return prisma.berita.delete({
		where: { id_berita: Number(id) },
	});
};

// Helper: Serialize response
export const serialize = (req, item) => {
	if (!item) return item;
	return {
		...item,
		gambar_berita: buildFileUrl(req, item.gambar_berita),
	};
};
