import cloudinary from "../config/cloudinary.js";
import streamifier from "streamifier";

export const uploadFileToCloudinary = (fileBuffer, folderName = "rpl") => {
  return new Promise((resolve, reject) => {
    if (!fileBuffer || fileBuffer.length === 0) {
      console.error("Upload gagal: file buffer kosong!");
      return reject(new Error("File buffer is empty"));
    }
    console.log(`Starting upload to Cloudinary [${folderName}]. Buffer size:`, fileBuffer.length);
    
    const uploadStream = cloudinary.uploader.upload_stream(
      { folder: folderName, resource_type: "auto" },
      (error, result) => {
        if (error) {
          console.error("Cloudinary upload error:", error);
          return reject(error);
        }
        console.log("Cloudinary upload success:", result.secure_url);
        resolve(result);
      }
    );
    
    const stream = streamifier.createReadStream(fileBuffer);
    stream.on('error', (err) => {
      console.error("Streamifier pipe error:", err);
      reject(err);
    });
    stream.pipe(uploadStream);
  });
};

export const buildFileUrl = (req, fileName) => {
  if (!fileName) return null;
  
  // Jika sudah berupa URL (Cloudinary atau external), kembalikan langsung
  if (/^https?:\/\//i.test(fileName)) return fileName;
  
  // Jika hanya berupa filename, berikan prefix URL backend
  // Prioritas: BACKEND_URL dari env > protocol + host dari request
  const baseUrl = process.env.BACKEND_URL || (req ? `${req.protocol}://${req.get("host")}` : "");
  
  // Pastikan tidak ada double slash jika baseUrl diakhiri /
  const cleanBaseUrl = baseUrl.endsWith("/") ? baseUrl.slice(0, -1) : baseUrl;
  
  return `${cleanBaseUrl}/uploads/${fileName}`;
};

export const deleteFile = async (fileIdentifier) => {
  if (!fileIdentifier) return;
  
  // Jika ini adalah URL Cloudinary, ekstrak public_id dan hapus
  if (fileIdentifier.includes("cloudinary.com")) {
    try {
      const parts = fileIdentifier.split("/upload/");
      if (parts.length > 1) {
        const publicIdWithExt = parts[1].replace(/^v\d+\//, "");
        const lastDotIndex = publicIdWithExt.lastIndexOf(".");
        const publicId = lastDotIndex !== -1 ? publicIdWithExt.substring(0, lastDotIndex) : publicIdWithExt;
        
        // Optimize: Jalankan penghapusan image & raw secara paralel untuk mempercepat response
        await Promise.allSettled([
          cloudinary.uploader.destroy(publicId, { resource_type: "image" }),
          cloudinary.uploader.destroy(publicId, { resource_type: "raw" })
        ]);
      }
    } catch (err) {
      console.error("Failed to delete file from Cloudinary:", err);
    }
  }
};
